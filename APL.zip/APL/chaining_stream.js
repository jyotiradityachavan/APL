const fs = require('fs');
const zlib = require('zlib');

// Chain read → compress → write
fs.createReadStream('input.txt')
  .pipe(zlib.createGzip())
  .pipe(fs.createWriteStream('input.txt.gz'))
  .on('finish', () => {
    console.log('File successfully compressed!');
  });
