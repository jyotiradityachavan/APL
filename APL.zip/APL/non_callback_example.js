const fs = require("fs");


try {
    let data = fs.readFileSync("non_callback.txt", "utf8");
    console.log("Non-callback File content:", data);
} catch (err) {
    console.error("Error reading file:", err.message);
}
