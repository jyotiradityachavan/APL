import React, { useState } from 'react';
import {
  Alert,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Breadcrumbs,
  Button,
  ButtonGroup,
  Divider,
  Fab,
  LinearProgress,
  Menu,
  MenuItem,
  Popover,
  Rating,
  Skeleton,
  SpeedDial,
  SpeedDialIcon,
  SpeedDialAction,
  Pagination,
  Typography,
  Link,
  Box
} from '@mui/material';
import {
  ExpandMore,
  Save,
  Print,
  Share
} from '@mui/icons-material';

function App() {
  const [anchorEl, setAnchorEl] = useState(null);
  const [ratingValue, setRatingValue] = useState(2);
  const [menuAnchorEl, setMenuAnchorEl] = useState(null);
  const [speedDialOpen, setSpeedDialOpen] = useState(false);

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const handleMenuClick = (event) => {
    setMenuAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setMenuAnchorEl(null);
  };

  const openPopover = Boolean(anchorEl);

  return (
    <Box sx={{ p: 4 }}>
      {/* Alert */}
      <Alert severity="success" sx={{ mb: 2 }}>This is a success alert!</Alert>

      {/* Accordion */}
      <Accordion>
        <AccordionSummary expandIcon={<ExpandMore />}>
          <Typography>Accordion 1</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>This is the detail of Accordion 1</Typography>
        </AccordionDetails>
      </Accordion>

      {/* Breadcrumbs */}
      <Breadcrumbs aria-label="breadcrumb" sx={{ my: 2 }}>
        <Link underline="hover" color="inherit" href="/">Home</Link>
        <Link underline="hover" color="inherit" href="/catalog">Catalog</Link>
        <Typography color="text.primary">Item</Typography>
      </Breadcrumbs>

      {/* Button Group */}
      <ButtonGroup variant="contained" sx={{ mb: 2 }}>
        <Button>One</Button>
        <Button>Two</Button>
        <Button>Three</Button>
      </ButtonGroup>

      {/* Divider */}
      <Divider sx={{ my: 2 }} />

      {/* Floating Action Button */}
      <Fab color="primary" aria-label="add" sx={{ mb: 2 }}>
        <Save />
      </Fab>

      {/* Linear Progress */}
      <LinearProgress sx={{ my: 2 }} />

      {/* Menu */}
      <div>
        <Button variant="contained" onClick={handleMenuClick}>Open Menu</Button>
        <Menu anchorEl={menuAnchorEl} open={Boolean(menuAnchorEl)} onClose={handleMenuClose}>
          <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
          <MenuItem onClick={handleMenuClose}>Settings</MenuItem>
          <MenuItem onClick={handleMenuClose}>Logout</MenuItem>
        </Menu>
      </div>

      {/* Popover */}
      <div>
        <Button aria-describedby="simple-popover" variant="contained" onClick={handlePopoverOpen} sx={{ my: 2 }}>
          Open Popover
        </Button>
        <Popover
          id="simple-popover"
          open={openPopover}
          anchorEl={anchorEl}
          onClose={handlePopoverClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
        >
          <Typography sx={{ p: 2 }}>The content of the Popover.</Typography>
        </Popover>
      </div>

      {/* Rating */}
      <Box sx={{ my: 2 }}>
        <Rating
          name="simple-controlled"
          value={ratingValue}
          onChange={(event, newValue) => {
            setRatingValue(newValue);
          }}
        />
      </Box>

      {/* Skeleton */}
      <Box sx={{ my: 2 }}>
        <Skeleton variant="text" width={210} />
        <Skeleton variant="circular" width={40} height={40} />
        <Skeleton variant="rectangular" width={210} height={60} />
      </Box>

      {/* SpeedDial */}
      <SpeedDial
        ariaLabel="SpeedDial example"
        sx={{ position: 'absolute', bottom: 16, right: 16 }}
        icon={<SpeedDialIcon />}
        onClose={() => setSpeedDialOpen(false)}
        onOpen={() => setSpeedDialOpen(true)}
        open={speedDialOpen}
      >
        <SpeedDialAction icon={<Save />} tooltipTitle="Save" />
        <SpeedDialAction icon={<Print />} tooltipTitle="Print" />
        <SpeedDialAction icon={<Share />} tooltipTitle="Share" />
      </SpeedDial>

      {/* Pagination */}
      <Box sx={{ my: 4 }}>
        <Pagination count={10} color="primary" />
      </Box>
    </Box>
  );
}

export default App;
