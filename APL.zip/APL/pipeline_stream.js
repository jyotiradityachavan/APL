const fs = require('fs');
const zlib = require('zlib');
const { pipeline } = require('stream');

// Compress input.txt → output.txt.gz
pipeline(
  fs.createReadStream('input.txt'),
  zlib.createGzip(),
  fs.createWriteStream('output.txt.gz'),
  (err) => {
    if (err) {
      console.error('Pipeline failed:', err);
    } else {
      console.log('Pipeline succeeded!');
    }
  }
);
