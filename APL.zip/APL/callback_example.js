const fs = require("fs");

// Async callback version
fs.readFile("callback.txt", "utf8", function(err, data) {
    if (err) {
        console.error("Error reading file:", err.message);
        return;
    }
    console.log("Callback File content:", data);
});
