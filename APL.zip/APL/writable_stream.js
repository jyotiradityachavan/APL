const fs = require('fs');

// Create a writable stream
const writable = fs.createWriteStream('output.txt');

// Write data in parts
writable.write('Hello ');
writable.write('World!\n');

// End the stream
writable.end('This is written using a writable stream.');

writable.on('finish', () => {
  console.log('Writing completed.');
});
