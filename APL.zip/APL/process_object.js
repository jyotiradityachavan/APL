console.log("Current working directory:", process.cwd());
console.log("Node.js version:", process.version);
console.log("Platform:", process.platform);
console.log("Process ID:", process.pid);

console.log("Command-line arguments:", process.argv);