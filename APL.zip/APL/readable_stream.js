const fs = require('fs');

// Create a readable stream
const readable = fs.createReadStream('input.txt', 'utf8');

// Read data in chunks
readable.on('data', (chunk) => {
  console.log('Received chunk:', chunk);
});

// When done reading
readable.on('end', () => {
  console.log('Finished reading file.');
});
