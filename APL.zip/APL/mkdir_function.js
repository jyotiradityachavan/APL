

// cretae directory


// const fs = require('fs');

// const folderName = './newFolder';

// fs.mkdir(folderName, (err) => {
//   if (err) {
//     return console.error('Error creating folder:', err);
//   }
//   console.log('Folder created successfully!');
// });



// Directory is Existing or not

// const fs = require('fs');

// const dir = './newFolder';

// if (fs.existsSync(dir)) {
//   console.log('✅ Directory exists!');
// } else {
//   console.log('❌ Directory does not exist.');
// }



// read directory

// const fs = require('fs');

// const dir = './newFolder';

// fs.readdir(dir, (err, files) => {
//   if (err) {
//     return console.error('Error reading directory:', err);
//   }
//   console.log('📂 Files in directory:', files);
// });



//rename directory

// const fs = require('fs');

// const oldDir = './newFolder';
// const newDir = './renamedDir';


// fs.rename(oldDir, newDir, (err) => {
//   if (err) {
//     return console.error('Error renaming directory:', err);
//   }
//   console.log('✅ Directory renamed successfully!');
// });




//Remove Directory

// const fs = require('fs');

// const dir = './renamedDir';

// fs.rmdir(dir, (err) => {
//   if (err) {
//     return console.error('Error removing directory:', err);
//   }
//   console.log('🗑️ Directory removed successfully!');
// });





//Directory info

const fs = require('fs');

const dir = './renamedDir';

fs.stat(dir, (err, stats) => {
  if (err) {
    return console.error('Error getting stats:', err);
  }
  console.log('📊 Is directory?', stats.isDirectory());
  console.log('📏 Size:', stats.size, 'bytes');
  console.log('🕒 Created:', stats.birthtime);
});





