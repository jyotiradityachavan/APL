var express = require('express');
var app = express();

app.get('/', function(req, res){
  res.send("Hello world!");
});

const PORT = process.env.PORT || 4000; // <-- change to 4000 or any free port
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
