
const fs = require('fs');


fs.writeFile('example.txt', 'Hello, Node.js!', (err) => {
  if (err) throw err;
  console.log('File created & data written!');
  

  fs.appendFile('example.txt', '\nThis is appended content.', (err) => { 
    if (err) throw err;
    console.log('Content appended!');


    fs.readFile('example.txt', 'utf8', (err, data) => {
      if (err) throw err;
      console.log('\nFile Content:\n', data);

      
    fs.rename('example.txt', 'new_example.txt', (err) => {
        if (err) throw err;
        console.log('File renamed!');

        
    // fs.unlink('new_example.txt', (err) => {
    //       if (err) throw err;
    //       console.log('File deleted!');
    //     });
      });
    });
  });
});
